# Netlify redirects file for single-page applications
/*    /index.html   200

# Force HTTPS
http://raleskip.com/*    https://raleskip.com/:splat    301!
http://www.raleskip.com/*    https://www.raleskip.com/:splat    301!

# Redirect www to non-www (optional - choose one)
https://www.raleskip.com/*    https://raleskip.com/:splat    301!